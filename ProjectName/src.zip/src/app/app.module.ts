import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';      // Routeur de base
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';

// ******************************************************
// Home
import { HomeComponent } from './home/home.component';

// Shared
import { NavbarComponent } from './Shared/navbar/navbar.component';
import { FooterComponent } from './Shared/footer/footer.component';

// Demos :
import { Binding1Component } from './demo/binding1/binding1.component';
import { TwoWaysBinding2Component } from './demo/two-ways-binding2/two-ways-binding2.component';
import { Eventbinding3Component } from './demo/eventbinding3/eventbinding3.component';
import { Four0four4Component } from './demo/four0four4/four0four4.component';
import { Propertymodel5Component } from './demo/propertymodel5/propertymodel5.component';
import { Thepipes6Component } from './demo/thepipe6/thepipe6.component';
import { Custompipes7Component } from "./demo/custompipes7/custompipes7.component";
import { PowPipe } from './demo/custompipes7/pow.pipes';

// Exos :
import { CalculetteComponent } from './exo/calculette/calculette.component';
import { ConvertisseurComponent } from './exo/convertisseur/convertisseur.component';
import { ConvertTimerPipe } from "./exo/convertisseur/convertTime.pipe";
import { ConvertDegresPipe } from './exo/convertisseur/convertdegres.pipe';
// ******************************************************

// Décorateur :
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    FooterComponent,
    Binding1Component,
    TwoWaysBinding2Component,
    Eventbinding3Component,
    CalculetteComponent,
    Four0four4Component,
    Propertymodel5Component,
    Thepipes6Component,
    Custompipes7Component,
    PowPipe,
    ConvertisseurComponent,
    ConvertTimerPipe,
    ConvertDegresPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],                          // BLL : Business Logic Layer (Règles) Ajout utiliseur age > 18ans + HTTP (API)
  bootstrap: [AppComponent]
})
export class AppModule { }
