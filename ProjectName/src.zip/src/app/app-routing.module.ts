import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { Binding1Component } from './demo/binding1/binding1.component';
import { TwoWaysBinding2Component } from './demo/two-ways-binding2/two-ways-binding2.component';
import { Eventbinding3Component } from './demo/eventbinding3/eventbinding3.component';
import { Four0four4Component } from './demo/four0four4/four0four4.component';
import { Propertymodel5Component } from './demo/propertymodel5/propertymodel5.component';
import { Thepipes6Component } from './demo/thepipe6/thepipe6.component';
import { Custompipes7Component } from './demo/custompipes7/custompipes7.component';
import { CalculetteComponent } from './exo/calculette/calculette.component';
import { ConvertisseurComponent } from './exo/convertisseur/convertisseur.component';

const routes: Routes = [                              // A rajouter pour le routeur HomeComponent.
  {path: "", component: HomeComponent},
  {path:"demo/binding1", component: Binding1Component},
  {path:"demo/two-ways-binding2", component: TwoWaysBinding2Component},
  {path:"demo/eventbinding3", component: Eventbinding3Component},
  {path:"demo/four0four4", component: Four0four4Component},
  {path:"demo/propertymodel5", component: Propertymodel5Component},
  {path:"demo/thepipe6", component : Thepipes6Component},
  {path:"demo/custompipes7", component: Custompipes7Component},


  {path:"exo/calculette", component: CalculetteComponent},
  {path:"exo/convertisseur", component: ConvertisseurComponent},

  {path: "**", component: Four0four4Component}   // Pour rediriger vers page 404
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash : true})],    // /!\ Utiliser {useHash : true} sur Mac
  exports: [RouterModule]
})
export class AppRoutingModule { }
