import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-four0four4',
  templateUrl: './four0four4.component.html',
  styleUrls: ['./four0four4.component.css']
})
export class Four0four4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}